import { PrismaClient } from '@prisma/client';
import { hash } from 'bcryptjs';
import { faker } from '@faker-js/faker';

const prisma = new PrismaClient();

function getRandomInt(max: number) {
  return Math.floor(Math.random() * max);
}

const main = async () => {
  const password = await hash('S3nh@.S3cr3t@', 8);

  await prisma.user.create({
    data: {
      name: 'Luan Verdelho',
      email: 'luanverdelho642@gmail.com',
      password
    }
  });

  await prisma.user.createMany({
    data: [...Array(24).keys()].map(() => ({
      name: `${faker.person.firstName()} ${faker.person.lastName()}`,
      email: faker.internet.email(),
      password
    }))
  });

  const users = await prisma.user.findMany();

  await prisma.task.createMany({
    data: [...Array(1000).keys()].map(() => ({
      title: faker.lorem.sentence({ min: 3, max: 5 }),
      userId: users[getRandomInt(25)].id,
      completionForecast: faker.date.soon({ days: 25 })
    }))
  });
};
main()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => await prisma.$disconnect()); // eslint-disable-line
