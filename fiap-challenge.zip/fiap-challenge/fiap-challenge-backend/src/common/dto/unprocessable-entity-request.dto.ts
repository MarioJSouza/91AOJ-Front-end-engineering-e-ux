import { ApiProperty } from '@nestjs/swagger';

export class UnprocessableEntityResponseDTO {
  @ApiProperty({
    type: Number,
    description: 'Código do erro HTML',
    example: 422,
    required: true
  })
  statusCode: 422;

  @ApiProperty({
    type: Object,
    description: 'Resposta da API',
    example: {
      status: 'error',
      errors: {
        email: ['Email already exists']
      }
    },
    required: true
  })
  body: {
    status: 'error';
    errors: {
      email: ['Email already exists'];
    };
  };
}
