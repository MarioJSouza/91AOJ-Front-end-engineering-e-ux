declare module 'AppLogger' {
  fail(obj);
}