import { Expose } from 'class-transformer';
import { IsEmail, MaxLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class AuthUserResponseDTO {
  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'User Protocol',
    example: 'cfe90ca4-dd6c-4ec1-8ae8-a1102356901f'
  })
  id: string;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'User full name',
    example: 'Bruce Wayne'
  })
  name: string;

  @Expose()
  @IsEmail()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'User email.',
    example: 'batman@gmail.com'
  })
  email: string;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'user creation date',
    example: '2024-05-10T02:08:18.051Z'
  })
  createdAt: Date;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'user update date',
    example: '2024-05-10T02:08:18.051Z'
  })
  updatedAt: Date;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    nullable: true,
    description: 'user deleted date',
    example: null
  })
  deletedAt: Date;
}
