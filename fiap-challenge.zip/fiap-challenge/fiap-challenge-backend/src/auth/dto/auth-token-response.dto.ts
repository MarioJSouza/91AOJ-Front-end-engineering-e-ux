import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';
import { MaxLength } from 'class-validator';

export class AuthTokenResponseDTO {
  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'Token for access',
    example: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9'
  })
  accessToken: string;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'Token expiration time',
    example: 1746865700
  })
  accessTokenExpiresIn: string;

  @Expose()
  @MaxLength(255)
  @ApiProperty({
    type: String,
    description: 'Token type sent',
    example: 'bearer'
  })
  tokenType: string;
}
