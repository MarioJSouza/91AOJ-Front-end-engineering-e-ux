import { AuthTokenResponseDTO } from '~/auth/dto/auth-token-response.dto';
import { ApiProperty } from '@nestjs/swagger';
import { AuthUserResponseDTO } from '~/auth/dto/auth-user-response.dto';

export class AuthResponseDTO {
  @ApiProperty({
    description: 'Token details',
    example: AuthTokenResponseDTO
  })
  token: AuthTokenResponseDTO;

  @ApiProperty({
    description: 'User details',
    example: AuthUserResponseDTO
  })
  user: AuthUserResponseDTO;
}
