import { Module } from '@nestjs/common';
import { RootService } from './root/root.service';
import { AuthModule } from './auth/auth.module';
import { UsersModule } from './users/users.module';
import { TasksModule } from './tasks/tasks.module';

@Module({
  providers: [RootService],
  imports: [AuthModule, UsersModule, TasksModule]
})
export class AppModule {}
