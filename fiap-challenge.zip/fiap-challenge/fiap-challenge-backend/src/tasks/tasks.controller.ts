import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Patch,
  Post,
  UnauthorizedException,
  UseGuards
} from '@nestjs/common';
import { TasksService } from '~/tasks/tasks.service';
import { Task } from '@prisma/client';
import { GetUser } from '~/common/decorators';
import { AuthUserResponseDTO } from '~/auth/dto';
import { AuthGuard } from '@nestjs/passport';
import {
  ApiBadRequestResponse,
  ApiBearerAuth,
  ApiCreatedResponse,
  ApiOkResponse,
  ApiTags,
  ApiUnauthorizedResponse
} from '@nestjs/swagger';
import { BadRequestDTO, UnauthorizedRequestDTO } from '~/common/dto';
import { TasksCreationRequestDTO, TasksResponseDTO } from '~/tasks/dto';

@UseGuards(AuthGuard('jwt'))
@ApiBearerAuth('bearer')
@ApiTags('tasks')
@Controller('tasks')
export class TasksController {
  constructor(private tasksService: TasksService) {}

  @ApiOkResponse({ type: [TasksResponseDTO] })
  @ApiBadRequestResponse({ type: BadRequestDTO })
  @ApiUnauthorizedResponse({ type: UnauthorizedRequestDTO })
  @Get()
  async getAllTasks(@GetUser() user: AuthUserResponseDTO): Promise<Task[]> {
    console.log(user);
    return this.tasksService.getAllTasks(user.id);
  }

  @ApiCreatedResponse({ type: TasksResponseDTO })
  @ApiBadRequestResponse({ type: BadRequestDTO })
  @ApiUnauthorizedResponse({ type: UnauthorizedRequestDTO })
  @Post()
  async createNewTask(
    @GetUser() user: AuthUserResponseDTO,
    @Body() body: TasksCreationRequestDTO
  ) {
    try {
      return await this.tasksService.createTask(body, user.id);
    } catch (e) {
      throw new BadRequestException();
    }
  }

  @ApiOkResponse({ type: TasksResponseDTO })
  @ApiBadRequestResponse({ type: BadRequestDTO })
  @ApiUnauthorizedResponse({ type: UnauthorizedRequestDTO })
  @Patch(':id')
  async toggleTask(
    @GetUser() user: AuthUserResponseDTO,
    @Param('id') taskId: string
  ): Promise<any> {
    try {
      return await this.tasksService.toggleTask(taskId, user.id);
    } catch (e) {
      if (e.status === 401) throw new UnauthorizedException();
      throw new BadRequestException();
    }
  }
}
