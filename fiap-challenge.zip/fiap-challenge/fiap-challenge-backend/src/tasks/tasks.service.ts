import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AppLogger } from '~/app.logger';
import { Task } from '@prisma/client';
import { TasksRepository } from '~/tasks/tasks.repository';
import { TasksCreationRequestDTO } from '~/tasks/dto';

@Injectable()
export class TasksService {
  constructor(
    private readonly logger: AppLogger,
    private readonly tasksRepository: TasksRepository
  ) {
    this.logger.setContext(TasksService.name);
  }

  async getAllTasks(id: string): Promise<Task[]> {
    return await this.tasksRepository.getAll({
      where: {
        userId: id
      }
    });
  }

  async createTask(task: TasksCreationRequestDTO, userId: string) {
    return await this.tasksRepository.create({ ...task, userId });
  }

  async toggleTask(taskId: string, userId: string) {
    const task = await this.tasksRepository.findUnique({
      id: taskId
    });

    if (task.userId !== userId) throw new UnauthorizedException();

    task.conclusionDate = task.conclusionDate ? null : new Date();

    await this.tasksRepository.patch(taskId, task);

    return task;
  }
}
