import { Module } from '@nestjs/common';
import { TasksService } from './tasks.service';
import { TasksController } from './tasks.controller';
import { AppLogger } from '~/app.logger';
import { PrismaService } from '~/common/services';
import { TasksRepository } from '~/tasks/tasks.repository';

@Module({
  providers: [TasksService, TasksRepository, AppLogger, PrismaService],
  controllers: [TasksController]
})
export class TasksModule {}
