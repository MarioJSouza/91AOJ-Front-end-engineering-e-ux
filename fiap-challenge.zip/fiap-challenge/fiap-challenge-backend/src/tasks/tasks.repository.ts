import { Injectable } from '@nestjs/common';
import { PrismaService } from '~/common/services';
import { Prisma, Task } from '@prisma/client';

@Injectable()
export class TasksRepository {
  constructor(private readonly prismaService: PrismaService) {}

  async create(data: Prisma.TaskUncheckedCreateInput) {
    return this.prismaService.task.create({ data });
  }

  async getAll(params: {
    where?: Prisma.TaskWhereInput;
    include?: Prisma.TaskInclude;
  }): Promise<Task[]> {
    const { where, include } = params;
    return this.prismaService.task.findMany({
      where,
      include,
      orderBy: { createdAt: 'desc' }
    });
  }

  async findUnique(where: Prisma.TaskWhereUniqueInput) {
    return this.prismaService.task.findUnique({ where });
  }

  async patch(id: string, data: Prisma.TaskUpdateInput) {
    await this.prismaService.task.update({ data, where: { id } });
  }
}
