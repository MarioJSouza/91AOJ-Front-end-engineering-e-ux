import { ApiProperty } from '@nestjs/swagger';
import { MaxLength } from 'class-validator';

export class TasksCreationRequestDTO {
  @MaxLength(255)
  @ApiProperty({
    type: String,
    required: true,
    description: 'Task title',
    example: 'Task 1'
  })
  title: string;

  @ApiProperty({
    type: Date,
    required: true,
    description: 'Expected task completion date',
    example: '2024-05-20T04:43:01.362Z'
  })
  completionForecast: Date;
}
