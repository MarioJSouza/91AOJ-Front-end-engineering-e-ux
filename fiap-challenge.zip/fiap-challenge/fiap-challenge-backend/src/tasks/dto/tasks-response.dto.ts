import { ApiProperty } from '@nestjs/swagger';

export class TasksResponseDTO {
  @ApiProperty({
    type: String,
    required: true,
    description: 'Protocol task',
    example: 'd32185cd-a4e4-47f3-80fe-47e80f7beb73'
  })
  id: string;

  @ApiProperty({
    type: String,
    required: true,
    description: 'User protocol task',
    example: 'd32185cd-a4e4-47f3-80fe-47e80f7beb73'
  })
  userId: string;

  @ApiProperty({
    type: String,
    required: true,
    description: 'Title task',
    example: 'Titulo 1'
  })
  title: string;

  @ApiProperty({
    type: Date,
    required: true,
    description: 'Expectation of completing the task',
    example: '2024-05-13T04:08:32.461Z'
  })
  completionForecast: Date;

  @ApiProperty({
    type: Date,
    nullable: true,
    description: 'Task completion date',
    example: null
  })
  conclusionDate: Date | null;

  @ApiProperty({
    type: Date,
    nullable: true,
    description: 'Task creation date',
    example: '2024-05-10T03:12:03.592Z'
  })
  createdAt: Date | null;

  @ApiProperty({
    type: Date,
    nullable: true,
    description: 'Task update date',
    example: '2024-05-10T03:12:03.592Z'
  })
  updatedAt: Date | null;

  @ApiProperty({
    type: Date,
    nullable: true,
    description: 'Task deleted date',
    example: null
  })
  'deletedAt': Date | null;
}
