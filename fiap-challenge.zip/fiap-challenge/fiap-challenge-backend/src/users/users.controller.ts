import { Body, Controller, Post } from '@nestjs/common';
import { UserCredentialRequestDTO } from '~/users/dto';
import { UsersService } from '~/users/users.service';
import {
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiTags,
  ApiUnprocessableEntityResponse
} from '@nestjs/swagger';
import { AuthUserResponseDTO } from '~/auth/dto';
import { BadRequestDTO, UnprocessableEntityResponseDTO } from '~/common/dto';

@ApiTags('users')
@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @ApiCreatedResponse({ type: AuthUserResponseDTO })
  @ApiUnprocessableEntityResponse({ type: UnprocessableEntityResponseDTO })
  @ApiBadRequestResponse({ type: BadRequestDTO })
  @Post()
  async createUser(@Body() params: UserCredentialRequestDTO) {
    return await this.usersService.createUser(params);
  }
}
