import { Module } from '@nestjs/common';
import { UsersService } from './users.service';
import { PrismaService } from '~/common/services';
import { AppLogger } from '~/app.logger';
import { UsersRepository } from '~/users/users.repository';
import { UsersController } from '~/users/users.controller';

@Module({
  providers: [UsersService, UsersRepository, AppLogger, PrismaService],
  controllers: [UsersController],
  exports: [UsersService]
})
export class UsersModule {}
