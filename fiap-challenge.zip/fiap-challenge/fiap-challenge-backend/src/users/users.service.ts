import { Injectable, UnprocessableEntityException } from '@nestjs/common';
import { Prisma, User as UserModel } from '@prisma/client';
import { AppLogger } from '~/app.logger';
import { UsersRepository } from './users.repository';

@Injectable()
export class UsersService {
  constructor(
    private readonly logger: AppLogger,
    private readonly userRepository: UsersRepository
  ) {
    this.logger.setContext(UsersService.name);
  }

  async createUser(params: Prisma.UserCreateInput) {
    const user = await this.userRepository.findUnique({
      where: { email: params.email }
    });

    if (user) throw new UnprocessableEntityException();
    return await this.userRepository.createUser(params);
  }

  async getUser(userWhereUniqueInput: Prisma.UserWhereUniqueInput) {
    const user: UserModel | null = await this.userRepository.findUnique({
      where: userWhereUniqueInput
    });

    return user;
  }
}
