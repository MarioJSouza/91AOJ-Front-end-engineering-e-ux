<script setup lang="ts">

</script>

<template>
  <router-view :key='$route.path' />
</template>
