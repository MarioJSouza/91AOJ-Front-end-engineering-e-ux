import {createApp} from 'vue'
import './style.css'
import App from './App.vue'
import {DashboardTag, LoginTag, RegisterTag} from "~/app/presentation/pages";
import {createMemoryHistory, createRouter} from "vue-router";

const routes = [
    {path: '/', name: 'login', component: LoginTag},
    {path: '/register', name: 'register', component: RegisterTag},
    {path: '/dashboard', name: 'dashboard', component: DashboardTag}
]

const router = createRouter({
    history: createMemoryHistory(),
    routes,
})

createApp(App)
    .use(router)
    .mount('#app')
