export * from './remote-authentication-decorator';
