import * as Yup from 'yup';

export const makeRegisterValidation = Yup.object().shape({
    name: Yup.string().required('Campo obrigatório').min(3, 'Precisa ser no minimo 3 caracteres'),
    email: Yup.string()
        .email('Formato do e-mail está incorreto')
        .required('Campo obrigatório'),
    password: Yup.string().required('Campo obrigatório').min(8, 'Sua senha tem que ser no entre 8 a 20 Caracteres').max(20, 'Sua senha tem que ser no entre 8 a 20 Caracteres')
});

