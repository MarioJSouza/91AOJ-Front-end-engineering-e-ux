import * as Yup from 'yup';

export const makeLoginValidation = Yup.object().shape({
    email: Yup.string()
        .email('Formato do e-mail está incorreto')
        .required('Campo obrigatório'),
    password: Yup.string().required('Campo obrigatório')
});

