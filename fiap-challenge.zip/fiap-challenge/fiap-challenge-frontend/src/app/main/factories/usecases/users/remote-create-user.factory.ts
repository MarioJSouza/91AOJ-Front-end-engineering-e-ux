import {RemoteCreateUser} from "~/app/application/usecases";
import {makeAxiosHttpClient} from "~/app/main/factories/http";

export const makeRemoteCreateUser = () => {
    return new RemoteCreateUser('/v1/users', makeAxiosHttpClient())
}