import {RemoteToggleTask} from "~/app/application/usecases";
import {makeAuthorizedHttpClientDecorator} from "~/app/main/factories/decorators";

export const makeRemoteToggleTask = () => {
  return new RemoteToggleTask('/v1/tasks', makeAuthorizedHttpClientDecorator())
}