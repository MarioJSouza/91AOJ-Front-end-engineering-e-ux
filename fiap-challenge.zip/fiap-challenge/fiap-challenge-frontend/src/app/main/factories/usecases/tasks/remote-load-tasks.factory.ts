import {RemoteLoadTasks} from "~/app/application/usecases";
import {makeAuthorizedHttpClientDecorator} from "~/app/main/factories/decorators";

export const makeRemoteLoadTasks = () => {
    return new RemoteLoadTasks('/v1/tasks', makeAuthorizedHttpClientDecorator());
}