import {RemoteCreateTask} from "~/app/application/usecases";
import {makeAuthorizedHttpClientDecorator} from "~/app/main/factories/decorators";

export const makeRemoteCreateTask = () => {
    return new RemoteCreateTask('/v1/tasks', makeAuthorizedHttpClientDecorator());
}