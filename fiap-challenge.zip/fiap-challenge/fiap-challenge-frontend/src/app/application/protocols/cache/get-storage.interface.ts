export interface GetStorage {
    get: (key: string) => any;
}
