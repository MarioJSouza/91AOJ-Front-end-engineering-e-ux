import { HttpStatusCodeEnum } from '~/app/application/protocols/http';

export type HttpResponse<BodyData = any> = {
    statusCode: HttpStatusCodeEnum | undefined;
    body?: BodyData;
};
