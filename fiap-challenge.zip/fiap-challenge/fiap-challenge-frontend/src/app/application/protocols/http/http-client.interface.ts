import { HttpResponse, HttpRequestParams } from '~/app/application/protocols/http';

export interface HttpClient<ResponseData = any> {
    request: (params: HttpRequestParams) => Promise<HttpResponse<ResponseData>>;
}
