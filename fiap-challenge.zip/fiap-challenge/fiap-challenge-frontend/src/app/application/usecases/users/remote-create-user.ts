import {CreateUser} from "~/app/domain/usecases/users";
import {HttpClient, HttpStatusCodeEnum} from "~/app/application/protocols/http";
import {AccessDeniedError, UnexpectedError, UnprocessableEntityError} from "~/app/domain/errors";

export class RemoteCreateUser implements CreateUser {
    constructor(
        private readonly url: string,
        private readonly httpClient: HttpClient<RemoteCreateUser.Response>
    ) {}

    async create(params: RemoteCreateUser.Params): Promise<RemoteCreateUser.Response> {
        const httpResponse = await this.httpClient.request({
            method: 'post',
            url: this.url,
            body: params
        })

        switch (httpResponse.statusCode) {
            case HttpStatusCodeEnum.ok:
                return httpResponse.body as RemoteCreateUser.Response;
            case HttpStatusCodeEnum.created:
                return httpResponse.body as RemoteCreateUser.Response;
            case HttpStatusCodeEnum.noContent:
                return {} as RemoteCreateUser.Response;
            case HttpStatusCodeEnum.unauthorized:
            case HttpStatusCodeEnum.badRequest:
            case HttpStatusCodeEnum.forbidden:
                throw new AccessDeniedError();
            case HttpStatusCodeEnum.UnprocessableEntity:
                throw new UnprocessableEntityError();
            default:
                throw new UnexpectedError();
        }
    }
}

export namespace RemoteCreateUser {
    export type Params = CreateUser.Params;
    export type Response = CreateUser.Response;
}