import {ToggleTask} from "~/app/domain/usecases";
import {HttpClient, HttpStatusCodeEnum} from "~/app/application/protocols/http";
import {AccessDeniedError, UnexpectedError} from "~/app/domain/errors";
import {RemoteLoadTasks} from "~/app/application/usecases/tasks/remote-load-tasks.ts";

export class RemoteToggleTask implements ToggleTask {
    constructor(
        private readonly url: string,
        private readonly httpClient: HttpClient<RemoteToggleTask.Response>,
    ) {
    }

    async toggle(params: RemoteToggleTask.Params) {
        const url = `${this.url}/${params.id}`;

        const httpResponse = await this.httpClient.request({
            url,
            method: 'patch',
        })

        switch (httpResponse.statusCode) {
            case HttpStatusCodeEnum.ok:
                return httpResponse.body as RemoteLoadTasks.Response;
            case HttpStatusCodeEnum.noContent:
                return {} as RemoteLoadTasks.Response;
            case HttpStatusCodeEnum.unauthorized:
            case HttpStatusCodeEnum.badRequest:
            case HttpStatusCodeEnum.forbidden:
                throw new AccessDeniedError();
            default:
                throw new UnexpectedError();
        }
    }
}

export namespace RemoteToggleTask {
    export type Params = ToggleTask.Params;
    export type Response = ToggleTask.Response
}