import {CreateTask} from "~/app/domain/usecases";
import {HttpClient, HttpStatusCodeEnum} from "~/app/application/protocols/http";
import {AccessDeniedError, UnexpectedError} from "~/app/domain/errors";

export class RemoteCreateTask implements CreateTask {
    constructor(
        private readonly url: string,
        private readonly httpClient: HttpClient<RemoteCreateTask.Response>) {
    }

    async create(params: RemoteCreateTask.Params): Promise<RemoteCreateTask.Response> {
        const httpResponse = await this.httpClient.request({
            method: 'post',
            url: this.url,
            body: params
        })


        switch (httpResponse.statusCode) {
            case HttpStatusCodeEnum.ok:
                return httpResponse.body as RemoteCreateTask.Response;
            case HttpStatusCodeEnum.created:
                return httpResponse.body as RemoteCreateTask.Response;
            case HttpStatusCodeEnum.noContent:
                return {} as RemoteCreateTask.Response;
            case HttpStatusCodeEnum.unauthorized:
            case HttpStatusCodeEnum.badRequest:
            case HttpStatusCodeEnum.forbidden:
                throw new AccessDeniedError();
            default:
                throw new UnexpectedError();
        }
    }

}

export namespace RemoteCreateTask {
    export type Params = CreateTask.Params;
    export type Response = CreateTask.Response;
}