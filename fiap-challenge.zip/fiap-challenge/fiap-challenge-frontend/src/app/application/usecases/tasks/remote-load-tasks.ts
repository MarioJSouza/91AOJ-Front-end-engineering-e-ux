import {LoadTasks} from "~/app/domain/usecases";
import {HttpClient, HttpStatusCodeEnum} from "~/app/application/protocols/http";
import {AccessDeniedError, UnexpectedError} from "~/app/domain/errors";

export class RemoteLoadTasks implements LoadTasks {
    constructor(
        private readonly url: string,
        private readonly httpClient: HttpClient<RemoteLoadTasks.Response[]>,
    ) {
    }

    async load(): Promise<RemoteLoadTasks.Response[]> {
        const httpResponse = await this.httpClient.request({
            method: 'get',
            url: this.url
        })

        switch (httpResponse.statusCode) {
            case HttpStatusCodeEnum.ok:
                return httpResponse.body as RemoteLoadTasks.Response[];
            case HttpStatusCodeEnum.noContent:
                return [] as RemoteLoadTasks.Response[];
            case HttpStatusCodeEnum.unauthorized:
            case HttpStatusCodeEnum.badRequest:
            case HttpStatusCodeEnum.forbidden:
                throw new AccessDeniedError();
            default:
                throw new UnexpectedError();
        }
    }

}

export namespace RemoteLoadTasks {
    export type Response = LoadTasks.Response
}