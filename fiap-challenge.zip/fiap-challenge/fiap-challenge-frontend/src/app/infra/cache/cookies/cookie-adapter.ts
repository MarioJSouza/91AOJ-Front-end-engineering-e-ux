import Cookie  from 'universal-cookie';
import { GetStorage, SetStorage } from '~/app/application/protocols/cache';

export class CookieAdapter implements SetStorage, GetStorage {
    private cookies = new Cookie();

    set(key: string, value?: object): void {
        if (value) {
            this.cookies.set(key, JSON.stringify(value), {
                maxAge: 60 * 60 * 24 * 30,
                path: '/'
            });
        } else {
            this.cookies.remove(key);
        }
    }

    get(key: string): any {
        return  this.cookies.get(key) ?? null;
    }
}
