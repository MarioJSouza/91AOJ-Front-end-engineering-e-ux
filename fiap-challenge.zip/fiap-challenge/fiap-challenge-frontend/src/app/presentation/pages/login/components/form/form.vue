<script setup lang="ts">
import {ButtonTag, TextFieldTag, ToastTag} from "~/app/presentation/components/common";
import EmailIcon from '~/app/presentation/assets/mail.svg'
import PassIcon from '~/app/presentation/assets/lock.svg'
import {reactive, ref} from "vue";
import {useRouter} from 'vue-router'
import {makeLoginValidation} from "~/app/main/factories/pages";
import {makeRemoteAuthenticationDecorator} from "~/app/main/factories/decorators";

const route = useRouter()

const toast = ref(false)
const formInput = reactive({email: "", password: ""});
const errors: Record<string, string> = reactive({email: "", password: ""});


function activeToast() {
  toast.value = true

  setTimeout(() => {
    toast.value = false
  }, 2000)
}

async function onSubmit(e: any) {
  try {
    e.preventDefault();
    errors.email = '';
    errors.password = '';
    makeLoginValidation.validateSync(formInput, {abortEarly: false})

    await makeRemoteAuthenticationDecorator().signIn(formInput)

    await route.push({path: '/dashboard'})

  } catch (e: any) {
    if (!!e.inner?.length) {
      for (const element of e.inner) {
        errors[element.path] = element.message
      }
      return;
    }

    activeToast()
  }
}

</script>

<template>
  <form class="form" @submit="onSubmit">
    <div class="input-group">
      <TextFieldTag :error="errors.email" v-model="formInput.email" :icon="EmailIcon"
                    placeholder="Insira o seu E-mail"/>
      <TextFieldTag :error="errors.password" v-model="formInput.password" type="password" :icon="PassIcon"
                    placeholder="Insira a sua senha"/>
    </div>

    <RouterLink class="helper" to="/register">Cadastre-se</RouterLink>

    <ButtonTag text="Login"/>

    <ToastTag :show="toast" message="Email e/ou Senha incorretos"/>
  </form>
</template>

<style scoped>
@import url('./form.css');
</style>