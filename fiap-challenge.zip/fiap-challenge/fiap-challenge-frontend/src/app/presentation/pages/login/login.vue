<script setup lang="ts">
import { FormTag } from './components'
</script>

<template>
  <div class="login">
    <div class="login-wrapper">
      <img class="fiap-logo" src="../../assets/logo.svg">

      <FormTag />
    </div>
  </div>
</template>

<style scoped>
@import url('./login.css');
</style>