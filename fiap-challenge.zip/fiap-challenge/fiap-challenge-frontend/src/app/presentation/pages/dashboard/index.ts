export { default as DashboardTag } from './dashboard.vue';
