<script setup lang="ts">
import {
  AddButtonTag,
  EmptyStateTag,
  ModalTag,
  TaskFilterBarTag,
  TodoCardTag
} from "~/app/presentation/components/common";
import {BaseLayoutTag} from "~/app/presentation/layouts";
import {onMounted, reactive, ref} from "vue";
import {makeRemoteCreateTask, makeRemoteLoadTasks, makeRemoteToggleTask} from "~/app/main/factories/usecases";

const isAddTaskOpened = ref(false);

const formatTask = {title: '', completionForecast: ''}

const loading = ref(false)
let newTaskRef = reactive(formatTask)
let tasks = reactive<any[]>([]);

const openModal = () => {
  isAddTaskOpened.value = true;
};
const closeModal = () => {
  isAddTaskOpened.value = false;
  newTaskRef = formatTask;
};

const submitHandler = async (e: Event) => {
  e.preventDefault();
  const response = await makeRemoteCreateTask().create({
    title: newTaskRef.title,
    completionForecast: new Date(newTaskRef.completionForecast),
  })
  tasks = [response, ...tasks];

  closeModal()
}

const handleToggle = async (taskId: string) => {
  const response = await makeRemoteToggleTask().toggle({id: taskId})
  tasks = tasks.map(task => {
    if (task.id === taskId) return response

    return task;
  })
}

onMounted(async () => {
  try {
    loading.value = true;
    tasks = await makeRemoteLoadTasks().load();

  } catch (e) {
    alert(`Failed to load tasks ${e}`);
  } finally {
    loading.value = false;
  }
})
</script>

<template>
  <BaseLayoutTag @modal-open="openModal">

    <div class="dashboard-content">
      <TaskFilterBarTag/>

      <div v-if="loading" class="loading">Loading...</div>
      <EmptyStateTag v-if="!tasks.length && !loading"/>

      <div class="task-box" v-if="!!tasks.length">
        <TodoCardTag v-for="(item) in tasks" @update:task="handleToggle" :task="item"/>
      </div>

      <div/>
    </div>

    <div class="add-button-wrapper">
      <AddButtonTag @modal-open="openModal"/>
    </div>

    <ModalTag :isOpen="isAddTaskOpened" @modal-close="closeModal" @submit="submitHandler" name="first-modal">
      <template #header>Adicionar uma Tarefa</template>
      <template #content>
        <form>
          <div class="modal-input-group">
            <input class="modal-input" v-model="newTaskRef.title" type="text" placeholder="Adicionar uma tarefa">
            <input class="modal-input" v-model="newTaskRef.completionForecast" type="date"
                   placeholder="Data de conclusão">
          </div>
          <div class="button-group">
            <button class="modal-button primary" type="submit">Salvar</button>
            <button class="modal-button secondary" @click="closeModal" type="button">Cancelar</button>
          </div>
        </form>

      </template>
      <template #footer>
        <div/>
      </template>
    </ModalTag>
  </BaseLayoutTag>
</template>

<style scoped>
@import url('./dashboard.css');
</style>