<script setup lang="ts">
import {ButtonTag, TextFieldTag} from "~/app/presentation/components/common";
import UserIcon from '~/app/presentation/assets/user.svg'
import EmailIcon from '~/app/presentation/assets/mail.svg'
import PassIcon from '~/app/presentation/assets/lock.svg'
import {reactive, ref} from "vue";
import {useRouter} from 'vue-router'
import {makeRegisterValidation} from "~/app/main/factories/pages";
import {makeRemoteCreateUser} from "~/app/main/factories/usecases";
import {UnprocessableEntityError} from "~/app/domain/errors";

const route = useRouter()

const isLoading = ref(false);
const formInput = reactive({name: "", email: "", password: ""});
const errors: Record<string, string> = reactive({name: "", email: "", password: ""});

async function onSubmit(e: any) {
  try {
    e.preventDefault();
    isLoading.value = true
    errors.email = '';
    errors.password = '';
    makeRegisterValidation.validateSync(formInput, {abortEarly: false})

    await makeRemoteCreateUser().create(formInput)

    await route.push({path: '/'})

  } catch (e: any) {
    if (!!e.inner?.length) {
      for (const element of e.inner) {
        errors[element.path] = element.message
      }
      return;
    }

    if(e instanceof UnprocessableEntityError) errors.email = 'Este e-mail já existe'

  } finally {
    isLoading.value = false
  }
}

</script>

<template>
  <form class="form" @submit="onSubmit">
    <div class="input-group">
      <TextFieldTag :error="errors.name" v-model="formInput.name" :icon="UserIcon"
                    placeholder="Insira o seu Nome"/>
      <TextFieldTag :error="errors.email" v-model="formInput.email" :icon="EmailIcon"
                    placeholder="Insira o seu E-mail"/>
      <TextFieldTag :error="errors.password" v-model="formInput.password" type="password" :icon="PassIcon"
                    placeholder="Insira a sua senha"/>
    </div>

    <p class="helper">Já possui conta? <RouterLink to="/">Entre</RouterLink></p>

    <ButtonTag :isLoading="isLoading" text="Cadastrar"/>

  </form>
</template>

<style scoped>
@import url('./form.css');
</style>