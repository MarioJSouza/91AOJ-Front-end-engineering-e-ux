<script setup lang="ts">
import { FormTag } from './components'
</script>

<template>
  <div class="register">
    <div class="register-wrapper">
      <img class="fiap-logo" src="../../assets/logo.svg">

      <FormTag />
    </div>
  </div>
</template>

<style scoped>
@import url('register.css');
</style>