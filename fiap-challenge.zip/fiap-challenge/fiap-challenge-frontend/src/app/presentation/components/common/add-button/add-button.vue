<script setup lang="ts">
import AddCircle from '~/app/presentation/assets/add-circle.svg'
import {defineEmits} from "vue";

const emit = defineEmits(["modal-open"]);

</script>

<template>
  <div @click="emit('modal-open')" role="button" class="add-button">
    <img :src="AddCircle" alt="Botão de adicionar">
    <p class="text-add">Adicionar uma tarefa</p>
  </div>
</template>

<style scoped>
@import url('./add-button.css');
</style>