<script setup lang="ts">
import Exit from '~/app/presentation/assets/exit.svg'
import {makeCookieAdapter} from "~/app/main/factories/cache";
import {TOKEN_NAME} from "~/config/vars.ts";
import {Authentication} from "~/app/domain/usecases";
import {useRouter} from "vue-router";

const router = useRouter();

const { user } = makeCookieAdapter().get(TOKEN_NAME) as Authentication.Response
const displayName = user.name.split(' ')[0].slice(0, 100)

const handleLogout = () => {
  makeCookieAdapter().set(TOKEN_NAME)
  router.push('/')
}

</script>

<template>
  <button @click="handleLogout" class="logout-button">
    Olá, {{displayName}}
    <img :src="Exit" alt="exit"/>
  </button>
</template>

<style scoped>
@import url('./logout-button.css');
</style>