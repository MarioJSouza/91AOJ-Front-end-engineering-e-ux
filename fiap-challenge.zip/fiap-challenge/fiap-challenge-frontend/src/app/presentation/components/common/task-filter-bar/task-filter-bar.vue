<script setup lang="ts">
import Filter from '~/app/presentation/assets/filter.svg'
</script>

<template>
  <div class="task-filter-bar">
    <p class="task-text">Tarefas</p>

    <button class="filter-button">
      <img :src="Filter" alt="icone de filtro">
    </button>
  </div>
</template>

<style scoped>
@import url('./task-filter-bar.css');
</style>