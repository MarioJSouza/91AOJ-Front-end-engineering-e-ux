<script setup lang="ts">

</script>

<template>
  <div class="footer">
    <p class="footer-text">© Copyright 2021. Todos os direitos reservados.</p>
  </div>
</template>

<style scoped>
  @import url('./footer.css');
</style>