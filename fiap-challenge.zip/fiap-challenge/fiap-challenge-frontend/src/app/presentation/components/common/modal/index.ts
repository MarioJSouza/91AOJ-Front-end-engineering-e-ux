export { default as ModalTag } from './modal.vue';
