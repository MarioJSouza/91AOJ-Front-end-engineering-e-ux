<script setup lang="ts">
import {LogoutButtonTag} from "~/app/presentation/components/common";
import Logo from '~/app/presentation/assets/logo.svg'
import { HeaderAddButtonTag } from './components';
import {defineEmits} from "vue";

const emit = defineEmits(["modal-open"]);
</script>

<template>
  <div class="header">
    <div class="header-wrapper">
      <div class="column logo-wrapper">
        <img class="logo" :src="Logo" alt="Logo FIAP">
      </div>

      <div class="column add-button-wrapper">
        <HeaderAddButtonTag @modal-open="emit('modal-open')" />
      </div>

      <div class="column logout-wrapper">
        <LogoutButtonTag/>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import url('./header.css');
</style>