<script setup lang="ts">
  type ButtonProps = {
    isLoading?: boolean;
    text?: string;
    type?: 'button' | 'submit' | 'reset'
  }

  defineProps<ButtonProps>()
</script>

<template>
<button :disabled="!!isLoading" :type="type" class="button">{{isLoading ? 'Carregando' : text}}</button>
</template>

<style scoped>
@import url('./button.css');
</style>