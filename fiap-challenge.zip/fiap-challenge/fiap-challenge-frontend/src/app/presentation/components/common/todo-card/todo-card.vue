<script setup lang="ts">
import {RadioButtonTag} from "~/app/presentation/components/common";
import {LoadTasks} from "~/app/domain/usecases";
import {ref} from "vue";

type TodoCardProps = { task: LoadTasks.Response }

const props = defineProps<TodoCardProps>();
const check = ref(!!props.task.conclusionDate)

const emit = defineEmits(['update:task']);

const onClick = () => {
  check.value = !check.value;
  emit('update:task', props.task.id)
}

</script>

<template>
  <div @click="onClick" class="todo-card">
    <RadioButtonTag :check="check"/>

    <div class="todo-card-info">
      <p class="todo-title">{{ task.title }}</p>
      <p class="todo-text">
        Conclusão em: {{
          new Date(task.conclusionDate ?? task.completionForecast).toLocaleDateString('pt-BR', {timeZone: 'UTC'})
        }}
      </p>
    </div>
  </div>
</template>

<style scoped>
@import url('./todo-card.css');
</style>