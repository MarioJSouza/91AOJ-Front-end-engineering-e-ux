<script setup lang="ts">
type TextFieldProps = {
  icon?: any;
  type?: 'text' | 'password';
  error?: string;
  placeholder?: string;
}

defineProps<TextFieldProps>()
const model = defineModel({required: true, type: String});


import {reactive, ref, watch} from "vue";
import {useFocus} from '@vueuse/core'

const inputInfo = reactive({
  className: 'text-field-content'
});

const target = ref(null);
const {focused} = useFocus(target)

watch(focused, (focused) => {
  if (focused) inputInfo.className = 'text-field-content focus'
  else inputInfo.className = 'text-field-content'
})


</script>

<template>
  <div>
    <div class="text-field-container">
      <div>
        <img :src="icon" alt="input icon">
      </div>
      <div :class="inputInfo.className">
        <input :type="type" :placeholder="placeholder" v-model="model" ref="target" class="text-field"/>
      </div>
    </div>
    <div class="error-container">
      <p class="error">{{ error }}</p>
    </div>
  </div>
</template>

<style scoped>
@import url('./text-field.css');
</style>