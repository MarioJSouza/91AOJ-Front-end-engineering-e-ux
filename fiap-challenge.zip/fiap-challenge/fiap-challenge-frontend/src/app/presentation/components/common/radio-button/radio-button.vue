<script setup lang="ts">
type RadioButtonProps = {
  check?: boolean
}
defineProps<RadioButtonProps>()
</script>

<template :key="check">
  <label class="radio-button"><slot />
    <input :checked="check" type="radio">
    <span class="checkmark"></span>
  </label>
</template>

<style scoped>
@import url('./radio-button.css');
</style>