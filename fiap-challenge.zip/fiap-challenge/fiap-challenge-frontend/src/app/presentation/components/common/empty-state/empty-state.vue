<script setup lang="ts">
import EmptyState from '~/app/presentation/assets/empty-state.svg'
</script>

<template>
  <div class="empty-state">
    <img class="empty-state-image" :src="EmptyState" alt='Icone de não encontrado'>
    <p class="empty-state-text">Você ainda não possui tarefas cadastradas!</p>
  </div>
</template>

<style scoped>
@import url('./empty-state.css');
</style>