<script setup lang="ts">
  type ToastProps = {
    show: boolean;
    message: string;
  }

  defineProps<ToastProps>()
</script>

<template>
<div v-if="show" class="toast-container">
  <p class="toast-text">{{message}}</p>
</div>
</template>

<style scoped>
@import url('./toast.css');
</style>