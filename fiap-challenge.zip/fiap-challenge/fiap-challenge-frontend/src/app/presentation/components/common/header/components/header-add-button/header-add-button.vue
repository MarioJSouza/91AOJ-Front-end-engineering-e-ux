<script setup lang="ts">
import Add from '~/app/presentation/assets/add.svg'
import {defineEmits} from "vue";

const emit = defineEmits(["modal-open"]);
</script>

<template>
<button @click="emit('modal-open')" class="header-add-button">
  <img :src="Add" alt="Icone de adicionar" />

  Adicionar Tarefa
</button>
</template>

<style scoped>
@import './header-add-button.css';
</style>