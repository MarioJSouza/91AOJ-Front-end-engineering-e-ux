<script setup lang="ts">
import {HeaderTag, FooterTag} from "~/app/presentation/components/common";
import {defineEmits} from "vue";

const emit = defineEmits(["modal-open"]);

</script>

<template>
  <div>
    <HeaderTag @modal-open="emit('modal-open')" />

    <div class="base-layout-content">
      <slot/>
    </div>

    <div class="footer-wrapper">
      <FooterTag/>
    </div>
  </div>
</template>

<style scoped>
@import url('./base-layout.css');
</style>