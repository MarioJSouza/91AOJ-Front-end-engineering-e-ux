export class UnprocessableEntityError extends Error {
    constructor(message = 'There was a problem with the provided entities') {
        super(message);
        this.name = UnprocessableEntityError.name;
    }
}
