import {LoadTasks} from "~/app/domain/usecases";

export interface CreateTask {
    create(params: CreateTask.Params): Promise<CreateTask.Response>;
}

export namespace CreateTask {
    export type Params = {
        title: string;
        completionForecast: Date;
    }

    export type Response = LoadTasks.Response
}