import {LoadTasks} from "~/app/domain/usecases";

export interface ToggleTask {
    toggle(params: ToggleTask.Params): Promise<ToggleTask.Response>
}

export namespace ToggleTask {
    export type Params = {
        id: string
    }

    export type Response = LoadTasks.Response
}