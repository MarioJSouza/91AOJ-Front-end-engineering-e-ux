export interface LoadTasks {
    load(): Promise<LoadTasks.Response[]>;
}

export namespace LoadTasks {
    export type Response = {
        id: string,
        userId: string,
        title: string,
        completionForecast: string,
        conclusionDate: string | null,
        createdAt: string,
        updatedAt: string,
        deletedAt: string | null
    }
}