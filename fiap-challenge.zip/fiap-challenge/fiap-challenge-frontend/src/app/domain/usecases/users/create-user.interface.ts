export interface CreateUser {
    create(params: CreateUser.Params): Promise<CreateUser.Response>
}

export namespace CreateUser {
    export type Params = {
        name: string;
        email: string;
        password: string;
    }

    export type Response = {
        id: string;
        name: string;
        email: string;
        createdAt: string;
        updatedAt: string;
        deletedAt: string | null;
    }
}