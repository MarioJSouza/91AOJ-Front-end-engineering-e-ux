import {defineConfig, loadEnv} from 'vite'
import path from 'path'
import vue from '@vitejs/plugin-vue'

// https://vitejs.dev/config/
export default ({mode}: any) => {
    process.env = { ...process.env, ...loadEnv(mode, process.cwd()) };

    return defineConfig({
        plugins: [vue()],
        server: {
            port: 8080,
        },
        resolve: {
            alias: {'~': path.resolve(__dirname, 'src')},
        },
        define: {
            'process.env': process.env
        }
    })
}
